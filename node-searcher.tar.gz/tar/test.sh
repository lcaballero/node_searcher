coffee -c -b -o build/ code/

./node_modules/mocha/bin/mocha --recursive build/tests/