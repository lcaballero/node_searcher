SELECT * FROM tile
WHERE id = $1;