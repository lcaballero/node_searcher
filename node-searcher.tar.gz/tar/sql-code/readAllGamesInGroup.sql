SELECT * FROM game
WHERE group_id = $1