SELECT * FROM board
WHERE user_id = $1;