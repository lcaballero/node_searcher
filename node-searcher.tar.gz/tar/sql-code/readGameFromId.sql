SELECT * FROM game
WHERE id = $1