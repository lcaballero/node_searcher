SELECT * FROM game
WHERE name = $1