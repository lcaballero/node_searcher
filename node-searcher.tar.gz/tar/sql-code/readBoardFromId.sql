SELECT * FROM board
WHERE id = $1;