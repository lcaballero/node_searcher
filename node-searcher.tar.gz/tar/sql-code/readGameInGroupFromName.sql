SELECT * FROM game
WHERE group_id = $1 AND name = $2