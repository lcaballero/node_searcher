SELECT * FROM tile
WHERE board_id = $1;