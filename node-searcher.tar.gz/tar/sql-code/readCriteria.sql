SELET * FROM criteria
WHERE id = $1;